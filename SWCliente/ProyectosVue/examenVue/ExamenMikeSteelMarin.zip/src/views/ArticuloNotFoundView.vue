<template>
    <h1>Error 404. Pagina no Encontrada, no se ha encontrado el articulo</h1>
    <VolverPokemons />
</template>
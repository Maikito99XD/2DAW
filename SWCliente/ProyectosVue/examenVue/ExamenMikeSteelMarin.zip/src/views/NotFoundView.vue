<template>
    <h1>Error 404. Pagina no Encontrada</h1>
    <VolverPokemons />
</template>
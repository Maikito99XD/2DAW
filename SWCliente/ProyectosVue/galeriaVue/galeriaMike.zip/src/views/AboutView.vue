<template>
  <div class="about">
    <h1>Practica 2</h1>
    <p>-----------</p>
    <h1>Components + Vue Router + Composables</h1>
    <p>-----------</p>
    <h1>Autor: Mike Steel Marín</h1>
  </div>
</template>

<style>
@media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
}
</style>

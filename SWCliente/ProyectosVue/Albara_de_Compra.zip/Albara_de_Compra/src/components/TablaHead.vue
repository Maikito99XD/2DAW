<script setup>

</script>

<template>
  <!--Simplemente se ha creado la linea de productos -->
<table rules="groups">
    <tr>
      <th>Producte</th>
      <th>Quantitat</th>
      <th>Preu</th>
      <th>Total</th>
      <th></th> 
    </tr>
</table>
</template>



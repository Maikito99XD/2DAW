<script setup>
    import VolverPokemons from '../components/VolverPokemons.vue';
</script>
<template>
    <h1>Error 404. Pagina no Encontrada</h1>
    <VolverPokemons />
</template>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Subida Imagen</title>
    <meta name="description" content="PHP">
    <meta name="author" content="Mike">
    <style>
		label, input{display: block;}
	</style>
</head>
<body>
<?php
require_once 'utils/classes/File.php';

$descripcion = '';
$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST')
{
    try
    {
        $descripcion = trim(htmlspecialchars($_POST['descripcion']));
        $tiposAceptados = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];

        $imagen = new File('imagen', $tiposAceptados);
        $imagen->saveUploadFile('images/');

        $mensaje = 'Datos enviados';
    }
    catch(FileException $fileException)
    {
        $mensaje = $fileException->getMessage();
    }
}

include 'views/form.view.php';

?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title> Desarrollo web con PHP</title>
<meta name="description" content="PHP">
<meta name="author" content="MIKE">
</head>
<body>
<h1>Tema 2: Actividad 13</h1>
<form action="PanelControl.php" method="POST">
<h1>Creando la sesion</h1>
<label for="nombres">Nombres:<br></label><br/>
<input type="text" id="nombre" name="nombre" value="" /><br/><br/>
<input type="submit" name="action" value="Crear Sesion" />
</form>
</body>
</html>
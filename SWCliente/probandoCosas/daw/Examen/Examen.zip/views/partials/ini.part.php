<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>CubiletePoker</title>
    <meta name="description" content="PHP">
    <meta name="author" content="Gabriel Lozano">
</head>
<body>
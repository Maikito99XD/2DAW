<?php

interface I_ElementoQueSeTira
{
    public function tira();
    public function getTirada();
}

?>
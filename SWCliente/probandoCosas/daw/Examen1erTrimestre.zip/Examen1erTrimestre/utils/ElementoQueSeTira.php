<?php
    interface ElementoQueSeTira{
        public function tira();

        public function getTirada();
    } 
?>
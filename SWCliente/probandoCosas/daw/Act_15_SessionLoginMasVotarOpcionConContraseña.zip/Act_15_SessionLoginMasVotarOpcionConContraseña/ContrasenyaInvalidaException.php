<?php
    class ContrasenyaInvalidaException extends Exception{

        private string $mensaje;

        function __construct($message){
            parent::__construct($message);
            $this->mensaje = $message;
        }
        public function contrasenyaInvalida(){
            echo $this->mensaje;
        } 
    }
?>
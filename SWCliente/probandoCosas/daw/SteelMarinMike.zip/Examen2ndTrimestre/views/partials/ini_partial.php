<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Examen Mike Steel Marín</title>
    <meta name="description" content="PHP">
    <meta name="author" content="Mike Steel Marín">
</head>
<body>
<?php
    require 'views/single_post.view.php';
?>
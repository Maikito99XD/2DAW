    <!-- Bootstrap core css -->
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<!-- Bootstrap core css -->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<!-- Font Awesome icons -->
	<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css">
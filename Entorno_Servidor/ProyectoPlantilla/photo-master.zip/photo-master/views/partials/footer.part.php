    <!-- Footer -->
    <footer>
     <div class="container text-muted text-center">
         <ul class="list-inline social-buttons">
            <li><a href="#"><i class="fa fa-facebook sr-icons"></i></a>
            </li>
            <li><a href="#"><i class="fa fa-twitter sr-icons"></i></a>
            </li>
            <li><a href="#"><i class="fa fa-google-plus sr-icons"></i></a>
            </li>
         </ul>
         <ul class="list-inline">
           <li class="footer-number"><i class="fa fa-phone sr-icons"></i>  (00228)92229954 </li>
           <li><i class="fa fa-envelope sr-icons"></i>  kouvenceslas93@gmail.com</li>
         </ul>
         <p>Photography Fanatic Template &copy; 2017</p>
     </div>
   </footer>
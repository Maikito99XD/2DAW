<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <title>PhotographItem-Responsive Theme | Blog</title>

    <?php
		include 'views/partials/links.part.php';
	?>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body id="page-top">

<!-- Navigation Bar -->
   <nav class="navbar navbar-fixed-top navbar-default">
     <div class="container">
       <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
            <a  class="navbar-brand page-scroll" href="#page-top">
              <span>[PHOTO]</span>
            </a>
       </div>
       <div class="collapse navbar-collapse navbar-right" id="menu">
          <ul class="nav navbar-nav">
            <li class=" lien"><a href="index.php"><i class="fa fa-home sr-icons"></i> Home</a></li>
            <li class="lien"><a href="about.php"><i class="fa fa-bookmark sr-icons"></i> About</a></li>
            <li class="active lien"><a href="#"><i class="fa fa-file-text sr-icons"></i> Blog</a></li>
            <li><a href="contact.php"><i class="fa fa-phone-square sr-icons"></i> Contact</a></li>
          </ul>
       </div>
     </div>
   </nav>
<!-- End of Navigation Bar -->

<!-- Principal Content Start -->
   <div id="blog">
     <div class="container">
      <div class="row">

      <!-- Blocks of Posts -->
        <div class="col-xs-12 col-sm-8 row">
           <div class="col-xs-12 col-sm-12">
             <div class="post">
               <div class="post-heading">
                 <span>6 JANUARY</span>
                 <img class="img-responsive" src="images/blog/landscape.jpg" alt="post's picture">
               </div>
               <div class="post-body">
                 <h3><a href="single_post.html"><strong>doloremque illum</strong></a></h3>
                 <hr>
                 <p>Duis ultrices tortor non felis convallis bibendum. Maecenas diam velit, sollicitudin at imperdiet ac, consectetur non nibh. Etiam eget dapibus nulla. 
                 </p>
               </div>
               <div class="post-footer">
                 <a class="btn" href="single_post.html">READ MORE...</a>
                 <span>
                 <i class="fa fa-heart sr-icons"></i> 10
                 <i class="fa fa-comments sr-icons"></i> 10
                 </span>
               </div>
             </div>
           </div>
           <div class="col-xs-12 col-sm-12">
             <div class="post">
               <div class="post-heading">
                 <span>7 FEBRUARY</span>
                 <img class="img-responsive" src="images/blog/family.jpg" alt="post's picture">
               </div>
               <div class="post-body">
                 <h3><a href="single_post.html"><strong>Lorem ipsum</strong></a></h3>
                 <hr>
                 <p>Nunc sit amet dapibus est, sit amet varius risus. Donec luctus lacinia mauris, at feugiat ligula facilisis ac. Class aptent taciti sociosqu ad litora torquent per conubia.
                 </p>
               </div>
               <div class="post-footer">
                 <a class="btn" href="single_post.html">READ MORE...</a>
                 <span>
                 <i class="fa fa-heart sr-icons"></i> 10
                 <i class="fa fa-comments sr-icons"></i> 10
                 </span>
               </div>
             </div>
           </div>
           <div class="col-xs-12 col-sm-12">
             <div class="post">
               <div class="post-heading">
                 <span>8 MARCH</span>
                 <img class="img-responsive" src="images/blog/elephant.jpg" alt="post's picture">
               </div>
               <div class="post-body">
                 <h3><a href="single_post.html"><strong>Aliquam soluta</strong></a></h3>
                 <hr>
                 <p>In felis ante, aliquet sit amet venenatis at, feugiat sed leo. Fusce pretium, velit in luctus ornare, elit lorem ultrices tortor, sed consectetur orci risus mollis ante. 
                 </p>
               </div>
               <div class="post-footer">
                 <a class="btn" href="single_post.html">READ MORE...</a>
                 <span>
                 <i class="fa fa-heart sr-icons"></i> 10
                 <i class="fa fa-comments sr-icons"></i> 10
                 </span>
               </div>
             </div>
           </div>
              <nav class="text-left">
                <ul class="pagination">
                  <li class="active"><a href="#">1</a></li>
                  <li><a href="#">2</a></li>
                  <li><a href="#">3</a></li>
                  <li><a href="#" aria-label="suivant">
                    <span aria-hidden="true">&raquo;</span>
                  </a></li>
                </ul>
              </nav>
        </div>
      <!-- End of Blog Post -->  

      <!-- Side bar -->  
        <div class="col-xs-12 col-sm-4">
           <form class="form-horizontal">
             <div class="input-group">
               <input class="form-control" type="text" placeholder="Research">
               <span class="input-group-btn">
                  <a href="" class="btn"><i class="fa fa-search"></i></a>
               </span>
             </div>
           </form>
           <div class="panel">
             <div class="panel-heading">
               <h4>Categories</h4>
             </div>
             <div class="panel-body">
               <ul class="nav">
                 <li><a href="#">Category I</a></li>
                 <li><a href="#">Category II</a></li>
                 <li><a href="#">Category III</a></li>
                 <li><a href="#">Category IV</a></li>
                 <li class="last"><a href="#">Category V</a></li>
               </ul>
             </div>
           </div>
           <div class="well">
             <h4>Soluta</h4>
             <p>Quod soluta corrupti earum officia vel inventore vitae quidem, consequuntur odit impedit.</p>
           </div>
            <h3>Recent Posts</h3>
            <hr>
             <div class="post">
               <div class="post-heading">
                 <span>10 APRIL</span>
                 <img class="img-responsive" src="images/blog/wedding.jpg" alt="post's picture">
               </div>
               <div class="post-body">
                 <span>
                 <i class="fa fa-heart sr-icons"></i> 10
                 <i class="fa fa-comments sr-icons"></i> 10
                 </span>
                 <h4 class="text-left"><a href="single_post.html"><strong>Aliquam soluta</strong></a></h4>
               </div>
             </div>
             <div class="post">
               <div class="post-heading">
                 <span>12 MAY</span>
                 <img class="img-responsive" src="images/blog/woman.jpg" alt="post's picture">
               </div>
               <div class="post-body">
                 <span>
                 <i class="fa fa-heart sr-icons"></i> 10
                 <i class="fa fa-comments sr-icons"></i> 10
                 </span>
                 <h4 class="text-left"><a href="single_post.html"><strong>Consequuntur</strong></a></h4>
               </div>
             </div>
        </div>
      <!-- End of Side bar --> 
       
      </div>
     </div>
   </div>
<!-- End of Principal Content Start --> 

   <?php
    include 'views/partials/footer.part.php';
    include 'views/partials/js.part.php';
   ?>
</body>
</html>
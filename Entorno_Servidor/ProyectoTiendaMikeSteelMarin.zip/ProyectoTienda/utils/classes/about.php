<?php
    session_start();

    include("../../views/about.view.php");
?>
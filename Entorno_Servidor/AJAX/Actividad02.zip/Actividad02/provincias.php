<select id="provincias">
    <option value="1">Valencia</option>
    <option value="2">Castellón</option>
    <option value="3">Alicante</option>    
</select>

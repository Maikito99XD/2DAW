<?php 
    echo "Tu dirección IP es: {$_SERVER['REMOTE_ADDR']}";
?>
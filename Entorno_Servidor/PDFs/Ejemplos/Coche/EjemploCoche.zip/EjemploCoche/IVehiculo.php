<?php

interface IVehiculo
{
    public function getModelo();
    public function getColor();
    public function ArrancarApagar();
}